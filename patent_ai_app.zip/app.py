import streamlit as st
import openai

st.set_page_config(page_title="特許生成AI", layout="wide")

st.title("🔬 特許生成AI - GPT搭載")
st.write("以下の情報を入力して、特許構成案を自動生成してください。")

api_key = st.text_input("OpenAI APIキーを入力してください（外部送信されません）", type="password")
theme = st.text_area("発明のテーマ（できれば詳しく）", height=200)

if st.button("特許構成を生成する"):
    if not api_key or not theme:
        st.error("APIキーとテーマを両方入力してください。")
    else:
        with st.spinner("生成中...（最大30秒ほどかかります）"):
            openai.api_key = api_key
            prompt = f"""
あなたはプロの特許技術者です。以下の発明テーマに基づき、構成要素の相互作用を含んだ詳細な特許構成案を1万字規模で出力してください。

【テーマ】
{theme}

【出力フォーマット】
1. 発明名称：
2. 技術分野・背景技術：
3. 解決しようとする課題：
4. 詳細な構成（相互作用を含む）：
5. 請求項（第1〜3項）：
6. 作用効果：
7. 構成図（文章による説明）：
8. 応用展開・派生応用：
9. 侵害回避設計：
10. 全体まとめ：
"""
            try:
                response = openai.ChatCompletion.create(
                    model="gpt-4",
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.7,
                )
                st.success("生成完了！")
                st.text_area("生成結果", response.choices[0].message["content"], height=600)
            except Exception as e:
                st.error(f"エラーが発生しました: {str(e)}")
